import 'reflect-metadata';
import { Class, DecoratorOpts, METHOD_METADATA, CONTROLLER_METADATA, CONTROLLER_METADATA_OBJ } from '../global';

export const Controller = (path: string, opts?: DecoratorOpts): ClassDecorator => {
    return (target: Class) => {
        const metadata = Reflect.getOwnMetadata(CONTROLLER_METADATA, CONTROLLER_METADATA_OBJ) || [];
        metadata.push({
            path,
            target,
            opts
        });
        Reflect.defineMetadata(CONTROLLER_METADATA, metadata, CONTROLLER_METADATA_OBJ);
    };
};

const createMethodsDecorator = (method: string, opts?: DecoratorOpts) => (path: string): MethodDecorator => {
    return (target, fnName, descriptor) => {
        const metadata = Reflect.getOwnMetadata(METHOD_METADATA, target.constructor) || [];
        metadata.push({
            path,
            opts,
            method,
            fnName,
            value: descriptor.value
        });
        Reflect.defineMetadata(METHOD_METADATA, metadata, target.constructor);
    };
};

export const Get = createMethodsDecorator('get');
export const Post = createMethodsDecorator('get');

export default {
    Controller,
    Get,
    Post
};
