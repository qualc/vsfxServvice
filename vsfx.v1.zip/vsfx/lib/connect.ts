import 'reflect-metadata';
import * as fs from 'fs';
import * as path from 'path';
import { use } from '../server';
import { Class, METHODDATA, METHODDATAS, METHOD_METADATA, CONTROLLER_METADATA, CONTROLLER_METADATA_OBJ } from '../global';

export const DefineRoute = (controllersPath: string | string[]) => {
    try {
        if (!Array.isArray(controllersPath)) {
            controllersPath = [controllersPath];
        }
        // 遍历挂载 controller
        controllersPath.forEach(cpaths => {
            __explorer(cpaths);
        });
        _defineMetadata();
    } catch (e) {
        console.log(`有路由挂载失败啦:~err:${e.stack}`);
    }
};

function _defineMetadata() {
    const metadata = Reflect.getOwnMetadata(CONTROLLER_METADATA, CONTROLLER_METADATA_OBJ);
    metadata.forEach((controller: Class) => {
        const routers: METHODDATAS = Reflect.getOwnMetadata(METHOD_METADATA, controller.target);
        if (routers) {
            routers.forEach((router: METHODDATA) => {
                use(router.path, <RouteHandle>router.value);
            });
        }
    });
}

// 递归加载 controller， 使其注入到 Reflect 中
function __explorer(cpaths: string) {
    try {
        let files = fs.readdirSync(cpaths);
        files.forEach(function(file) {
            let _path = path.join(cpaths, file);
            try {
                let statInfo = fs.statSync(_path);
                if (statInfo.isDirectory()) {
                    __explorer(_path);
                } else {
                    if (/\.[jt]s$/.test(path.parse(_path).ext)) {
                        require(_path);
                    }
                }
            } catch (e) {
                throw e;
            }
        });
    } catch (e) {
        console.log(`connect获取文件失败啦~err:${e.message}`);
    }
}
