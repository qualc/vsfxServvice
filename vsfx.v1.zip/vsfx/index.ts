import 'reflect-metadata';
export { DefineRoute } from './lib/connect';
export default {};
