/// <reference path="../index.d.ts" />
import http from 'http';
import path from 'path';
import fs from 'fs';
import etag from 'etag';
import { pathToRegexp } from 'path-to-regexp';
import IncomingMessageCustom from './request';
import ServerResponseCustom from './response';
import Router from './router';
declare type Config = {
    [key: string]: any;
};

class Application implements VApplication {
    config: Config = {};
    private router: Router;
    private staticStack: RegExp[] = [];
    constructor() {
        this.router = new Router(this);
        this.defaultConfiguration();
    }
    defaultConfiguration() {
        this.config['etag fn'] = this.getEtagFn();
    }
    getEtagFn() {
        return (body: any, encoding?: BufferEncoding) => {
            var buf = !Buffer.isBuffer(body) ? Buffer.from(body, encoding) : body;
            return etag(buf, { weak: true });
        };
    }
    static(filePath: string) {
        this.staticStack.push(pathToRegexp(filePath, [], { end: false }));
    }
    use(path: string, handle: RouteHandle) {
        this.router.use(path, handle);
    }
    beforeUse(path: any, handle?: any) {
        if (typeof path == 'function') {
            handle = path;
            path = '/';
        }
        this.router.useMiddleware(path, <RouteHandle>handle, 1);
    }
    afterUse(path: string, handle: RouteHandle) {
        this.router.useMiddleware(path, handle, 2);
    }
    handle(req: VRequest, res: VResponse) {
        const filePath: string = req.url || '';
        const isStatic = this.staticStack.some(reg => reg.test(filePath));
        if (isStatic) {
            const fullFilePath = path.join(process.cwd(), filePath);
            const state = fs.statSync(fullFilePath);
            if (state.isFile()) {
                res.sendFile(fullFilePath);
                return;
            }
        }
        this.router.handle(req, res);
    }
    listen(port: number = 3000, ...args: any[]) {
        const server = http.createServer(
            {
                IncomingMessage: IncomingMessageCustom,
                ServerResponse: ServerResponseCustom
            },
            (req, res) => {
                req.res = res;
                res.req = req;
                res.app = this;
                this.handle(req, res);
            }
        );
        return server.listen.call(server, port, ...args);
    }
}
export default Application;
